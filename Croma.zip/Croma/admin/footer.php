<footer class="main-footer">
    <strong>Copyright &copy; 2024-2025 <a href="index.php">Admin</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
    
    </div>
  </footer>